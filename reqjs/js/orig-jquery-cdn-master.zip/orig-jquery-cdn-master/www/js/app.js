// Configure loading modules from the lib directory, except 'app' ones,
// Place third party dependencies in the lib folder
//
requirejs.config({
    "baseUrl": "js/lib",
    "paths": {
      "app": "../app",
      // "jquery": "//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery"
      "jquery": "jquery"
    }
});

// Load the main app module to start the app
requirejs(["app/main"]);
